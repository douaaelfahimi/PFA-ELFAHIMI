/* eslint-disable no-unused-vars */
// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: import.meta.env.VITE_APP_FIREBASE_API_KEY,
  authDomain: "taskmanagerapp-696ee.firebaseapp.com",
  projectId: "taskmanagerapp-696ee",
  storageBucket: "taskmanagerapp-696ee.appspot.com",
  messagingSenderId: "600078909041",
  appId: "1:600078909041:web:506ce10a0ad08833f765d0"
};

// Initialize Firebase
export const app = initializeApp(firebaseConfig);