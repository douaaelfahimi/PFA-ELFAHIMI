/* eslint-disable react/prop-types */
import React from "react";
import clsx from "clsx";

const Button = ({ icon, className, label, type, onClick = () => {} }) => {
  return (
    <button
      className={clsx("bx-3 py-2 outline-none", className)}
      type={type || "button"}
      onClick={onClick}
    >
      <span>{label}</span>
      {icon && icon}
    </button>
  );
};

export default Button;
