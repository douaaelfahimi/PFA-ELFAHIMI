/* eslint-disable no-unused-vars */

// Import the apiSlice from the correct location
import { apiSlice } from "../apiSlice";

const AUTH_URL = "/user"; // Assuming "/user" is the base URL for authentication-related endpoints

// Inject endpoints for authentication API
export const authApiSlice = apiSlice.injectEndpoints({
    endpoints: (builder) => ({
        login: builder.mutation({
            query: (data) => ({
                url: `${AUTH_URL}/login`, // Construct the correct URL without including "/api"
                method: "POST",
                body: data,
                credentials: "include",
            }),
        }),

        register: builder.mutation({
            query: (data) => ({
                url: `${AUTH_URL}/register`, // Construct the correct URL without including "/api"
                method: "POST",
                body: data,
                credentials: "include",
            }),
        }),

        logout: builder.mutation({
            query: (data) => ({
                url: `${AUTH_URL}/logout`, // Construct the correct URL without including "/api"
                method: "POST",
                credentials: "include",
            }),
        }),
    }),
});


// Extract useLoginMutation hook from authApiSlice for use in components
export const { useLoginMutation , useRegisterMutation , useLogoutMutation } = authApiSlice;
